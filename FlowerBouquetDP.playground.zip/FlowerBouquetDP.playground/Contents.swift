import UIKit

var str = "Hello, playground"

func flowerBouquetWithDP(p: Int, q: Int, s: String) -> Int {
    var str = ""
    var dp = [Int].init(repeating: 0, count: s.count)
    for i in 0..<s.count {
        dp[i] = i == 0 ? 0 : dp[i-1]
        let indes = s.index(s.startIndex, offsetBy: i)
        str = str + String(s[indes])
        if str.contains("000") {
            if i == 2 {
                dp[i] = p
            } else {
                dp[i] = dp[i-1] > (p + dp[i-3]) ? dp[i-1] : p + dp[i-3]
            }
            
        } else if str.contains("01") || str.contains("10"){
            if i == 1 {
                dp[i] = q
            } else {
                dp[i] = dp[i-1] > (q + dp[i-2]) ? dp[i-1] : q + dp[i-2]
            }
        }
        if i >= 2 {
            str = String(s[indes])
        }
    }
    return dp[s.count-1]
}
